
from distutils.core import setup

setup(
    name='GetSerie',
    version='0.1dev',
    packages=['liberclass','thetvdb',],
    license='Creative Commons Attribution-Share Alike license',
    long_description=open('README.txt').read(),
)

