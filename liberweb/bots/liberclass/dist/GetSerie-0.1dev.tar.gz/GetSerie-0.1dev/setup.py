
from distutils.core import setup

setup(
    name='GetSerie',
    version='0.1dev',
    packages=['liberclass','thetvdb',],
    author='anders',
    author_email='anders@sindominio.net',
    license='Creative Commons Attribution-Share Alike license',
    long_description=open('README.txt').read(),
)

