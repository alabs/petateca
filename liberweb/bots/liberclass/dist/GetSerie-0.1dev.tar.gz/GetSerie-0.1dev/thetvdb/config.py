#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Clave para acceder a la API de thetvdb.com
"""
API_KEY = '8A016745146D9A85'

"""
User agent de urllib
"""
USER_AGENT = 'LiberCopyBot - bots@libercopy.net'

